﻿using Exam3Abganeev.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;


namespace Exam3Abganeev
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static Exam3AbganeevEntities DB = new Exam3AbganeevEntities();
        public static Users LoggedUser;
    }
}
