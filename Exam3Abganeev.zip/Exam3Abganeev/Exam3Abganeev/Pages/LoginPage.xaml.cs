﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exam3Abganeev.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void BSingIn_Click(object sender, RoutedEventArgs e)
        {
            string login = TBLogin.Text;
            string password = TBPassword.Text;
            string secretword = TBSecret.Text;

            var LoggedUser = App.DB.Users.FirstOrDefault(x => x.Login == login && x.Password == password && x.Secret == secretword);
            App.LoggedUser = LoggedUser;

            if (LoggedUser == null)
            {
                MessageBox.Show("Поля пусты, либо заполнены неверное");
                return;
            }
            if (LoggedUser.IdRole == 1)
            {
                NavigationService.Navigate(new ManagerPage());
                MessageBox.Show("Добро пожаловать!");
            }
            if (LoggedUser.IdRole == 2)
            {
                NavigationService.Navigate(new CallPage());
                MessageBox.Show("Добро пожаловать!");
            }
            if (LoggedUser.IdRole == 3)
            {
                NavigationService.Navigate(new CleanPage());
                MessageBox.Show("Добро пожаловать!");
            }
        }

        private void BExit_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();
        }
    }
}
