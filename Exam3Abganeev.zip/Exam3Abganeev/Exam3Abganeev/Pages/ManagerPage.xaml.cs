﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exam3Abganeev.Pages
{
    /// <summary>
    /// Логика взаимодействия для ManagerPage.xaml
    /// </summary>
    public partial class ManagerPage : Page
    {
        public ManagerPage()
        {
            InitializeComponent();
            DGUsers.ItemsSource = App.DB.Users.ToList();
            CBRole.ItemsSource = App.DB.Role.ToList();
            Refresh();
        }
        

        private void BAddUser_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BDeleteUser_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BEditUser_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void BBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void TBPoisk_TextChanged(object sender, TextChangedEventArgs e)
        {
            var filtred = App.DB.Users.ToList();
            var searchText = TBPoisk.Text.ToLower();
            if (!string.IsNullOrWhiteSpace(searchText))
                filtred = filtred.Where(x => x.FullName.ToLower().Contains(searchText)).ToList();
            DGUsers.ItemsSource = filtred;
        }

        private void CBRole_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Refresh();
        }
        public void Refresh()
        {
            
        }
    }
}
