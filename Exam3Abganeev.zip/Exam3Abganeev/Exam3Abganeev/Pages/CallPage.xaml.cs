﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exam3Abganeev.Pages
{
    /// <summary>
    /// Логика взаимодействия для CallPage.xaml
    /// </summary>
    public partial class CallPage : Page
    {
        public CallPage()
        {
            InitializeComponent();
            DGTasks.ItemsSource = App.DB.Tasks.ToList();
        }

        private void BAdd_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
